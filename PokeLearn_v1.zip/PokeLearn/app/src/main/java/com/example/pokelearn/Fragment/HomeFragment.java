package com.example.pokelearn.Fragment;

import android.content.Context;
import android.net.Uri;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.v4.app.Fragment;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.pokelearn.Courses;
import com.example.pokelearn.R;
import com.firebase.ui.database.FirebaseRecyclerAdapter;
import com.firebase.ui.database.FirebaseRecyclerOptions;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.squareup.picasso.Picasso;


public class HomeFragment extends Fragment {
    private View courseView;
    private RecyclerView courseList;
    private DatabaseReference databaseCourses;

    public HomeFragment() {
        // Required empty public constructor
    }

    @Override
    public View onCreateView (LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        courseView = inflater.inflate(R.layout.fragment_home,container, false);
        courseList=(RecyclerView) courseView.findViewById(R.id.myRecycleView);
        courseList.setLayoutManager(new LinearLayoutManager(getContext()));

        databaseCourses= FirebaseDatabase.getInstance().getReference().child("Courses");
        databaseCourses.keepSynced(true);

        return courseView;
    }


    @Override
    public void onStart() {
        super.onStart();

        FirebaseRecyclerOptions options =
                new FirebaseRecyclerOptions.Builder<Courses>()
                .setQuery(databaseCourses, Courses.class)
                .build();

         FirebaseRecyclerAdapter<Courses, CoursesViewHolder> adapter = new FirebaseRecyclerAdapter<Courses, CoursesViewHolder>(options) {
             @Override
             protected void onBindViewHolder(@NonNull CoursesViewHolder holder, int position, @NonNull Courses model) {
                 holder.course_name.setText(model.getCourseName());
                 holder.course_desc.setText(model.getCourseDesc());
                 Picasso.get().load(model.getCourseCoverImgUrl()).into(holder.course_img);
             }

             @NonNull
             @Override
             public CoursesViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int viewType) {
                 View view = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.course_row, viewGroup, false);
                 CoursesViewHolder viewHolder = new CoursesViewHolder(view);
                 return viewHolder;
             }
         };

         courseList.setAdapter(adapter);
         adapter.startListening();

    }

    public static class CoursesViewHolder extends RecyclerView.ViewHolder
    {
        TextView course_name,course_desc;
        ImageView course_img;

        public CoursesViewHolder(View itemView){
            super(itemView);
            course_name = itemView.findViewById(R.id.course_name);
            course_desc = itemView.findViewById(R.id.course_desc);
            course_img  = itemView.findViewById(R.id.course_img);
        }

    }


    public interface OnFragmentInteractionListener {
        // TODO: Update argument type and name
        void onFragmentInteraction(Uri uri);
    }
}
